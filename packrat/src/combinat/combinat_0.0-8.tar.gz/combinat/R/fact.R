"fact"<-
function(x)
gamma(x + 1)

