"logfact"<-
function(x)
lgamma(x + 1)

