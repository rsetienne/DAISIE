library(DAISIE)
source('invoke_IW.R')
system.time(IW())


