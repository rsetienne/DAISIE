Sys.setenv(R_TESTS = "")
library(testthat)
library(DAISIE)

test_check("DAISIE")